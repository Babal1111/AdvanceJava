package com.example.PaymentService.consumer;

import com.example.PaymentService.dto.OrderCreatedEvent;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

@Component
public class PaymentConsumer {

    @RabbitListener(queues = "payment.queue")
    public void processPayment(OrderCreatedEvent event) {
        System.out.println("[DIRECT] Processing Payment for Order: "+event.getOrderId());
        System.out.println("[DIRECT] Amount: "+ event.getAmount());
        System.out.println("[DIRECT] Payment Sucessful");

    }

    @RabbitListener(queues = "order.india.queue")
    public void handleIndiaOrder(OrderCreatedEvent event) {
        System.out.println("[TOPIC - INDIA] Received Order: "+event.getOrderId());
        System.out.println("[TOPIC - INDIA] Amount: "+ event.getAmount());
        System.out.println("[TOPIC - INDIA] Applying India regional processing...");
    }

    @RabbitListener(queues = "order.india.queue")
    public void handleUsaOrder(OrderCreatedEvent event) {
        System.out.println("[TOPIC - USA] Received Order: "+event.getOrderId());
        System.out.println("[TOPIC - USA] Amount: "+ event.getAmount());
        System.out.println("[TOPIC - USA] Applying India regional processing...");

    }
}